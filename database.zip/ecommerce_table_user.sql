
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UID` int(11) NOT NULL,
  `USERNAME` varchar(50) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `DATECREATED` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UID`, `USERNAME`, `PASSWORD`, `DATECREATED`) VALUES
(197, 'TAHAmir', '$2y$10$DsDx8LGr1PAwRwGMqK4lreye0i9s7VrBSO5zYMchWsBvtUGfMTtyS', '2020-12-01 10:14:17'),
(198, 'hello', '$2y$10$KqLMr4YBlgwzHrc5Rh4PXOnn6jvlCYocXDo8u0KVP1PXFdi9p.Brq', '2020-12-01 10:14:57'),
(199, 'wwwww', '$2y$10$gj/bBypZcOria0zeMpL/y.e5wxopBe5GlgQd86oteO3TFJ8QH0Ata', '2020-12-01 15:31:17'),
(200, 'abcd', '$2y$10$pOQBVYUaqZQld6I.JMWRduGw1zISqxXtifC5sjbBAnDrBg2k/JCC6', '2020-12-03 09:00:24'),
(201, 'mmmm', '$2y$10$n4tWTjCaavaLcpJg09R/Tea8UKgcyioFHz/8FgbISjz3yZdtDaH42', '2020-12-03 10:06:57'),
(202, 'Daniyal shafiq', '$2y$10$dl/w8CABXIQ0.86.n4cptu/.AfRwfjhgHT2cS5xAjdIcgpRgIr9VS', '2020-12-03 15:11:33');
